load('data_1.mat');
load('Test_data.mat');
result1 = svm(data_feat,data_label,data_feat1);
[c_matrixp,Result]= confusion.getMatrix(data_label,result1);
