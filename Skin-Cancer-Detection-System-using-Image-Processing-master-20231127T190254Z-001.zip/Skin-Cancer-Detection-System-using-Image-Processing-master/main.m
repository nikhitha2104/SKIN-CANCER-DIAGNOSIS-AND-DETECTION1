function varargout = main(varargin)
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @main_OpeningFcn, ...
                   'gui_OutputFcn',  @main_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
function main_OpeningFcn(hObject, eventdata, handles, varargin)
guidata(hObject, handles);

axes(handles.axes1); axis off
function varargout = main_OutputFcn(hObject, eventdata, handles) 
function pushbutton1_Callback(hObject, eventdata, handles)
[filename, pathname, filterindex]=uigetfile( ...
    {'*.jpg','JPEG File (*.jpg)'; ...
     '*.*','Any Image file (*.*)'}, ...
     'Pick an image file');
var=strcat(pathname,filename);
       k=imread(var);
       handles.YY = k;
       set(handles.edit1,'String',var);       
z=k;
guidata(hObject,handles);
axes(handles.axes1);
   imshow(k);
   title('INPUT IMAGE');
      
set(handles.pushbutton1,'enable','off');    
set(handles.pushbutton16,'enable','on');
function pushbutton2_Callback(hObject, eventdata, handles)
k=handles.YY;
j=rgb2gray(k);
handles.XX=j;
figure,subplot(2,2,2),imshow(j);title('gray Image');
set(handles.pushbutton1,'enable','off');    
set(handles.pushbutton2,'enable','off');
set(handles.pushbutton4,'enable','on');
function pushbutton3_Callback(hObject, eventdata, handles)
str=get(handles.edit1,'String');
I = imread(str);
h = ones(5,5)/25;
I2 = imfilter(I,h);
figure
imshow(I2)
title('Filtered Image')
set(handles.pushbutton3,'enable','off');
set(handles.pushbutton12,'enable','on');
function pushbutton4_Callback(hObject, eventdata, handles)
ei=25;
st=35;
k=ei*st;
I=handles.YY;
h = ones(ei,st) / k;
I1 = imfilter(I,h,'symmetric');
IG=rgb2gray(I1);
I11 = imadjust(IG,stretchlim(IG),[]);
level = graythresh(I11);
BWJ = im2bw(I11,level);
dim = size(BWJ)
IN=ones(dim(1),dim(2));
BW=xor(BWJ,IN);  %inverting
figure,subplot(2,2,2), imshow(BW), title('Black and White');
set(handles.pushbutton1,'enable','off');    
set(handles.pushbutton2,'enable','off');
set(handles.pushbutton3,'enable','on');
set(handles.pushbutton4,'enable','off');

function pushbutton5_Callback(hObject, eventdata, handles)
function pushbutton6_Callback(hObject, eventdata, handles)
I=handles.YY;
[y,x,z]=size(I);
myI=double(I);                 
H=zeros(y,x);
S=H;
HS_I=H;
for i=1:x
    for j=1:y
        HS_I(j,i)=((myI(j,i,1)+myI(j,i,2)+myI(j,i,3))/3);
        S(j,i)=1-3*min(myI(j,i,:))/(myI(j,i,1)+myI(j,i,2)+myI(j,i,3));
        if ((myI(j,i,1)==myI(j,i,2))&(myI(j,i,2)==myI(j,i,3)))       
            Hdegree=0;
        else    
            Hdegree=acos(0.5*(2*myI(j,i,1)-myI(j,i,2)-myI(j,i,3))/((myI(j,i,1)-myI(j,i,2))^2+(myI(j,i,1)-myI(j,i,3))*(myI(j,i,2)-myI(j,i,3)))^0.5);
        end    
        if (myI(j,i,2)>=myI(j,i,3))
            H(j,i)=Hdegree;                                    
        else
            H(j,i)=(2*pi-Hdegree);                              
        end     
    end 
end

Hth1=0.9*2*pi; Hth2=0.1*2*pi; 
Nred=0;                       
for i=1:x
    for j=1:y
        if ((H(j,i)>=Hth1)||(H(j,i)<=Hth2))
            Nred=Nred+1;       
        end
    end
end

Ratio=Nred/(x*y);           

if (Ratio>=0.6)              
    Red=1
else
    Red=0
end    

HS_I=uint8(HS_I);                                                    

figure(1);
imshow(I);
figure(2);
imshow(HS_I);
function pushbutton7_Callback(hObject, eventdata, handles)
createffnn
function pushbutton8_Callback(hObject, eventdata, handles)
str=get(handles.edit1,'String');
I1 = imread(str);
I = im2double(I1);
HSV = rgb2hsv(I);
H = HSV(:,:,1); H = H(:);
S = HSV(:,:,2); S = S(:);
V = HSV(:,:,3); V = V(:);
idx = kmeans([H S V], 4);
imshow(I1);
figure,imshow(ind2rgb(reshape(idx, size(I,1), size(I, 2)), [0 0 1; 0 0.8 0]))

function pushbutton9_Callback(hObject, eventdata, handles)
function pushbutton10_Callback(hObject, eventdata, handles)
function edit1_Callback(hObject, eventdata, handles)
function edit1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function [ Unow, center, now_obj_fcn ] = FCMforImage( img, clusterNum )

if nargin < 2
    clusterNum = 2;   
end

[row, col] = size(img);
expoNum = 2;      
epsilon = 0.001;  
mat_iter = 100;   

Upre = rand(row, col, clusterNum);
dep_sum = sum(Upre, 3);
dep_sum = repmat(dep_sum, [1,1, clusterNum]);
Upre = Upre./dep_sum;

center = zeros(clusterNum,1); 

for i=1:clusterNum
    center(i,1) = sum(sum(Upre(:,:,i).*img))/sum(sum(Upre(:,:,i)));
end

pre_obj_fcn = 0;
for i=1:clusterNum
    pre_obj_fcn = pre_obj_fcn + sum(sum((Upre(:,:,i) .*img - center(i)).^2));
end

for iter = 1:mat_iter    

    Unow = zeros(size(Upre));
    for i=1:row
        for j=1:col

            for uII = 1:clusterNum
                tmp = 0;
                for uJJ = 1:clusterNum
                    disUp = abs(img(i,j) - center(uII));
                    disDn = abs(img(i,j) - center(uJJ));
                    tmp = tmp + (disUp/disDn).^(2/(expoNum-1));
                end
                Unow(i,j, uII) = 1/(tmp);
            end            
        end
    end   

    now_obj_fcn = 0;
    for i=1:clusterNum
        now_obj_fcn = now_obj_fcn + sum(sum((Unow(:,:,i) .*img - center(i)).^2));
    end
   
    if max(max(max(abs(Unow-Upre))))<epsilon || abs(now_obj_fcn - pre_obj_fcn)<epsilon 
        break;
    else
        Upre = Unow.^expoNum;
       
        for i=1:clusterNum
            center(i,1) = sum(sum(Upre(:,:,i).*img))/sum(sum(Upre(:,:,i)));
        end
        pre_obj_fcn = now_obj_fcn;
    end
end

function pushbutton11_Callback(hObject, eventdata, handles)
function pushbutton12_Callback(hObject, eventdata, handles)
str=get(handles.edit1,'String');
I1 = imread(str);
str=rgb2gray(I1);
imwrite(str,'img.tif','tiff');
img = double(imread('img.tif'));
clusterNum = 2;
[ Unow, center, now_obj_fcn ] = FCMforImage( img, clusterNum );
figure;
subplot(2,2,1); imshow(img,[]);
for i=1:clusterNum
    subplot(2,2,i+1);
    imshow(Unow(:,:,i),[]);
    imwrite(Unow(:,:,i),'seg.jpg');
end
imshow('seg.jpg'); title('Segmented Image');

set(handles.pushbutton13,'enable','on');
set(handles.pushbutton12,'enable','off');

function pushbutton13_Callback(hObject, eventdata, handles)
s=get(handles.edit1,'String');
I = imread(s);
I=rgb2gray(I);
glcms = graycomatrix(I);
getData()
stats = graycoprops(glcms,'Contrast Correlation Energy Homogeneity');
Contrast = stats.Contrast;
Correlation = stats.Correlation;
Energy = stats.Energy;
Homogeneity = stats.Homogeneity;
seg_img=imread('seg.jpg');
Mean = mean2(seg_img);
Standard_Deviation = std2(seg_img);
Entropy = entropy(seg_img);
RMS = mean2(rms(seg_img));
Variance = mean2(var(double(seg_img)));
a = sum(double(seg_img(:)));
Smoothness = 1-(1/(1+a));
Kurtosis = kurtosis(double(seg_img(:)));
Skewness = skewness(double(seg_img(:)));

m = size(seg_img,1);
n = size(seg_img,2);
in_diff = 0;
for i = 1:m
    for j = 1:n
        temp = seg_img(i,j)./(1+(i-j).^2);
        in_diff = in_diff+temp;
    end
end
IDM = double(in_diff);
    
feat = [Contrast,Correlation,Energy,Homogeneity, Mean, Standard_Deviation, Entropy, RMS, Variance, Smoothness, Kurtosis, Skewness, IDM];
img = imread(s);
 gaborArray = gaborFilterBank(5,8,39,39);  % Generates the Gabor filter bank
 featureVector = gaborFeatures(img,gaborArray,4,4);
 disp('Gabor Feature');
 featureVector
 save('Gaborfeature.mat','featureVector');
set(handles.pushbutton14,'enable','on');
set(handles.pushbutton13,'enable','off');
msgbox('Feature Extracted Done');
clear all;
function [out] = GLCM_Features1(glcmin,pairs)
if ((nargin > 2) || (nargin == 0))
   error('Too many or too few input arguments. Enter GLCM and pairs.');
elseif ( (nargin == 2) ) 
    if ((size(glcmin,1) <= 1) || (size(glcmin,2) <= 1))
       error('The GLCM should be a 2-D or 3-D matrix.');
    elseif ( size(glcmin,1) ~= size(glcmin,2) )
        error('Each GLCM should be square with NumLevels rows and NumLevels cols');
    end    
elseif (nargin == 1) 
    pairs = 0; 
    if ((size(glcmin,1) <= 1) || (size(glcmin,2) <= 1))
       error('The GLCM should be a 2-D or 3-D matrix.');
    elseif ( size(glcmin,1) ~= size(glcmin,2) )
       error('Each GLCM should be square with NumLevels rows and NumLevels cols');
    end    
end


format long e
if (pairs == 1)
    newn = 1;
    for nglcm = 1:2:size(glcmin,3)
        glcm(:,:,newn)  = glcmin(:,:,nglcm) + glcmin(:,:,nglcm+1);
        newn = newn + 1;
    end
elseif (pairs == 0)
    glcm = glcmin;
end

size_glcm_1 = size(glcm,1);
size_glcm_2 = size(glcm,2);
size_glcm_3 = size(glcm,3);


out.autoc = zeros(1,size_glcm_3); 
out.contr = zeros(1,size_glcm_3); 
out.corrm = zeros(1,size_glcm_3);
out.corrp = zeros(1,size_glcm_3); 
out.cprom = zeros(1,size_glcm_3); 
out.cshad = zeros(1,size_glcm_3); 
out.dissi = zeros(1,size_glcm_3);
out.energ = zeros(1,size_glcm_3); 
out.entro = zeros(1,size_glcm_3); 
out.homom = zeros(1,size_glcm_3); 
out.homop = zeros(1,size_glcm_3); 
out.maxpr = zeros(1,size_glcm_3);

out.sosvh = zeros(1,size_glcm_3); 
out.savgh = zeros(1,size_glcm_3);
out.svarh = zeros(1,size_glcm_3); 
out.senth = zeros(1,size_glcm_3); 
out.dvarh = zeros(1,size_glcm_3);

out.denth = zeros(1,size_glcm_3);
out.inf1h = zeros(1,size_glcm_3); 
out.inf2h = zeros(1,size_glcm_3); 

out.indnc = zeros(1,size_glcm_3);
out.idmnc = zeros(1,size_glcm_3); 



glcm_sum  = zeros(size_glcm_3,1);
glcm_mean = zeros(size_glcm_3,1);
glcm_var  = zeros(size_glcm_3,1);


u_x = zeros(size_glcm_3,1);
u_y = zeros(size_glcm_3,1);
s_x = zeros(size_glcm_3,1);
s_y = zeros(size_glcm_3,1);




p_x = zeros(size_glcm_1,size_glcm_3); 
p_y = zeros(size_glcm_2,size_glcm_3); 
p_xplusy = zeros((size_glcm_1*2 - 1),size_glcm_3); 
p_xminusy = zeros((size_glcm_1),size_glcm_3);

hxy  = zeros(size_glcm_3,1);
hxy1 = zeros(size_glcm_3,1);
hx   = zeros(size_glcm_3,1);
hy   = zeros(size_glcm_3,1);
hxy2 = zeros(size_glcm_3,1);



for k = 1:size_glcm_3 

    glcm_sum(k) = sum(sum(glcm(:,:,k)));
    glcm(:,:,k) = glcm(:,:,k)./glcm_sum(k); 
    glcm_mean(k) = mean2(glcm(:,:,k)); 
    glcm_var(k)  = (std2(glcm(:,:,k)))^2;
    
    for i = 1:size_glcm_1

        for j = 1:size_glcm_2

            out.contr(k) = out.contr(k) + (abs(i - j))^2.*glcm(i,j,k);
            out.dissi(k) = out.dissi(k) + (abs(i - j)*glcm(i,j,k));
            out.energ(k) = out.energ(k) + (glcm(i,j,k).^2);
            out.entro(k) = out.entro(k) - (glcm(i,j,k)*log(glcm(i,j,k) + eps));
            out.homom(k) = out.homom(k) + (glcm(i,j,k)/( 1 + abs(i-j) ));
            out.homop(k) = out.homop(k) + (glcm(i,j,k)/( 1 + (i - j)^2));
           
            out.sosvh(k) = out.sosvh(k) + glcm(i,j,k)*((i - glcm_mean(k))^2);
            
            
            out.indnc(k) = out.indnc(k) + (glcm(i,j,k)/( 1 + (abs(i-j)/size_glcm_1) ));
            out.idmnc(k) = out.idmnc(k) + (glcm(i,j,k)/( 1 + ((i - j)/size_glcm_1)^2));
            u_x(k)          = u_x(k) + (i)*glcm(i,j,k); 
            u_y(k)          = u_y(k) + (j)*glcm(i,j,k); 

        end
        
    end
    out.maxpr(k) = max(max(glcm(:,:,k)));
end


for k = 1:size_glcm_3
    
    for i = 1:size_glcm_1
        
        for j = 1:size_glcm_2
            p_x(i,k) = p_x(i,k) + glcm(i,j,k); 
            p_y(i,k) = p_y(i,k) + glcm(j,i,k); % taking i for j and j for i
            if (ismember((i + j),[2:2*size_glcm_1])) 
                p_xplusy((i+j)-1,k) = p_xplusy((i+j)-1,k) + glcm(i,j,k);
            end
            if (ismember(abs(i-j),[0:(size_glcm_1-1)])) 
                p_xminusy((abs(i-j))+1,k) = p_xminusy((abs(i-j))+1,k) +...
                    glcm(i,j,k);
            end
        end
    end
    

    
end


for k = 1:(size_glcm_3)
    
    for i = 1:(2*(size_glcm_1)-1)
        out.savgh(k) = out.savgh(k) + (i+1)*p_xplusy(i,k);

        out.senth(k) = out.senth(k) - (p_xplusy(i,k)*log(p_xplusy(i,k) + eps));
    end

end

for k = 1:(size_glcm_3)
    
    for i = 1:(2*(size_glcm_1)-1)
        out.svarh(k) = out.svarh(k) + (((i+1) - out.senth(k))^2)*p_xplusy(i,k);

    end

end

for k = 1:size_glcm_3

    for i = 0:(size_glcm_1-1)
        out.denth(k) = out.denth(k) - (p_xminusy(i+1,k)*log(p_xminusy(i+1,k) + eps));
        out.dvarh(k) = out.dvarh(k) + (i^2)*p_xminusy(i+1,k);
    end
end


for k = 1:size_glcm_3
    hxy(k) = out.entro(k);
    for i = 1:size_glcm_1
        
        for j = 1:size_glcm_2
            hxy1(k) = hxy1(k) - (glcm(i,j,k)*log(p_x(i,k)*p_y(j,k) + eps));
            hxy2(k) = hxy2(k) - (p_x(i,k)*p_y(j,k)*log(p_x(i,k)*p_y(j,k) + eps));

        end
        hx(k) = hx(k) - (p_x(i,k)*log(p_x(i,k) + eps));
        hy(k) = hy(k) - (p_y(i,k)*log(p_y(i,k) + eps));
    end
    out.inf1h(k) = ( hxy(k) - hxy1(k) ) / ( max([hx(k),hy(k)]) );
    out.inf2h(k) = ( 1 - exp( -2*( hxy2(k) - hxy(k) ) ) )^0.5;

end

corm = zeros(size_glcm_3,1);
corp = zeros(size_glcm_3,1);

for k = 1:size_glcm_3
    for i = 1:size_glcm_1
        for j = 1:size_glcm_2
            s_x(k)  = s_x(k)  + (((i) - u_x(k))^2)*glcm(i,j,k);
            s_y(k)  = s_y(k)  + (((j) - u_y(k))^2)*glcm(i,j,k);
            corp(k) = corp(k) + ((i)*(j)*glcm(i,j,k));
            corm(k) = corm(k) + (((i) - u_x(k))*((j) - u_y(k))*glcm(i,j,k));
            out.cprom(k) = out.cprom(k) + (((i + j - u_x(k) - u_y(k))^4)*...
                glcm(i,j,k));
            out.cshad(k) = out.cshad(k) + (((i + j - u_x(k) - u_y(k))^3)*...
                glcm(i,j,k));
        end
    end
    
    s_x(k) = s_x(k) ^ 0.5;
    s_y(k) = s_y(k) ^ 0.5;
    out.autoc(k) = corp(k);
    out.corrp(k) = (corp(k) - u_x(k)*u_y(k))/(s_x(k)*s_y(k));
    out.corrm(k) = corm(k) / (s_x(k)*s_y(k));

end
function gaborArray = gaborFilterBank(u,v,m,n)





if (nargin ~= 4)    
    error('There must be four input arguments (Number of scales and orientations and the 2-D size of the filter)!')
end

gaborArray = cell(u,v);
fmax = 0.25;
gama = sqrt(2);
eta = sqrt(2);

for i = 1:u
    
    fu = fmax/((sqrt(2))^(i-1));
    alpha = fu/gama;
    beta = fu/eta;
    
    for j = 1:v
        tetav = ((j-1)/v)*pi;
        gFilter = zeros(m,n);
        
        for x = 1:m
            for y = 1:n
                xprime = (x-((m+1)/2))*cos(tetav)+(y-((n+1)/2))*sin(tetav);
                yprime = -(x-((m+1)/2))*sin(tetav)+(y-((n+1)/2))*cos(tetav);
                gFilter(x,y) = (fu^2/(pi*gama*eta))*exp(-((alpha^2)*(xprime^2)+(beta^2)*(yprime^2)))*exp(1i*2*pi*fu*xprime);
            end
        end
        gaborArray{i,j} = gFilter;
        
    end
end

figure('NumberTitle','Off','Name','Magnitudes of Gabor filters');
for i = 1:u
    for j = 1:v        
        subplot(u,v,(i-1)*v+j);        
        imshow(abs(gaborArray{i,j}),[]);
    end
end

figure('NumberTitle','Off','Name','Real parts of Gabor filters');
for i = 1:u
    for j = 1:v        
        subplot(u,v,(i-1)*v+j);        
        imshow(real(gaborArray{i,j}),[]);
    end
end

function featureVector = gaborFeatures(img,gaborArray,d1,d2)



if (nargin ~= 4)        
    error('Please use the correct number of input arguments!')
end

if size(img,3) == 3     
    warning('The input RGB image is converted to grayscale!')
    img = rgb2gray(img);
end

img = double(img);



[u,v] = size(gaborArray);
gaborResult = cell(u,v);
for i = 1:u
    for j = 1:v
        gaborResult{i,j} = imfilter(img, gaborArray{i,j});
    end
end



featureVector = [];
for i = 1:u
    for j = 1:v
        
        gaborAbs = abs(gaborResult{i,j});
        gaborAbs = downsample(gaborAbs,d1);
        gaborAbs = downsample(gaborAbs.',d2);
        gaborAbs = gaborAbs(:);
        
        
        gaborAbs = (gaborAbs-mean(gaborAbs))/std(gaborAbs,1);
        
        featureVector =  [featureVector; gaborAbs];
        
    end
end

function getData()
offsets = [0 1; -1 1;-1 0;-1 -1;2 2];
jpgImagesDir = fullfile('Dataset/Train', '*.jpg');
total = numel( dir(jpgImagesDir) );
jpg_files = dir(jpgImagesDir);
jpg_counter = 0;
gambar={total};
data_feat={total};
stats={total};
data_label={total};
label=1; 
limit=5; 

j=1;
for i=1:total
    s=strcat(num2str(i),'.jpg');
    file=fullfile('Dataset/Train',s);
    gambar{i}=imread(file);
    gambar{i}=imresize(gambar{i},[600 600]);
    gambar{i}=rgb2gray(gambar{i});
    glcm=graycomatrix(gambar{i}, 'Offset', offsets, 'Symmetric', true);
    stats{i}=graycoprops(glcm);

    iglcm=1;
    for x=1:5
      data_feat{i,x}=stats{i}.Contrast(iglcm);
      iglcm=iglcm+1;
    end
    iglcm=1;
    for x=6:10
        data_feat{i,x}=stats{i}.Correlation(iglcm);
        iglcm=iglcm+1;
    end
    iglcm=1;
    for x=12:16
        data_feat{i,x}=stats{i}.Energy(iglcm);
        iglcm=iglcm+1;
    end
        iglcm=1;
    for x=18:22
        data_feat{i,x}=stats{i}.Homogeneity(iglcm);
        iglcm=iglcm+1;
    end
        data_feat{i,24}=mean2(gambar{i});
        data_feat{i,25}=std2(gambar{i});
        data_feat{i,26}=entropy(gambar{i});
        data_feat{i,27}= mean2(var(double(gambar{i}))); 
        data_feat{i,28}=kurtosis(double(gambar{i}(:)));
        data_feat{i,29}=skewness(double(gambar{i}(:)));
        
        if i>limit
            label=label+1;
            data_label{i}=label;
            limit=limit+5;
        else
            data_label{1,i}=label;
        end         
end
data_feat=cell2mat(data_feat);
disp(data_feat);
data_label=cell2mat(data_label);
save('data_1.mat','data_feat','data_label');
function pushbutton14_Callback(hObject, eventdata, handles)
s=get(handles.edit1,'String');
test=imread(s);
grayImage = rgb2gray(test);
BGI = imopen(grayImage,strel('disk',15));
I2 = grayImage - BGI;
I3 = imadjust(I2);
level = graythresh(I3);
bw = im2bw(I3,level);
bw = bwareaopen(bw, 50);

% AREA CALCULATION
number_white = int2str(nnz(bw));
area = str2double(number_white);
test=imresize(test,[600 600]);
test=rgb2gray(test);
offsets = [0 1; -1 1;-1 0;-1 -1;2 2];

  glcm=graycomatrix(test, 'Offset', offsets, 'Symmetric', true);

stats=graycoprops(glcm);
data_glcm=struct2array(stats);
iglcm=1;
glcm_contrast={5};
glcm_correlation={5};
glcm_energy={5};
glcm_homogeneity={5};
    for x=1:5
      glcm_contrast{x}=data_glcm(iglcm);
      iglcm=iglcm+1;
    end
    for x=1:5
        glcm_correlation{x}=data_glcm(iglcm);
        iglcm=iglcm+1;
    end
    for x=1:5
        glcm_energy{x}=data_glcm(iglcm);
        iglcm=iglcm+1;
    end
    for x=1:5
        glcm_homogeneity{x}=data_glcm(iglcm);
        iglcm=iglcm+1;
    end
rata2=mean2(test);
std_deviation=std2(test);
glcm_entropy=entropy(test);
rata2_variance= mean2(var(double(test)));
glcm_kurtosis=kurtosis(double(test(:)));
glcm_skewness=skewness(double(test(:)));
buat_train=[glcm_contrast(1:5),glcm_correlation(1:5),glcm_energy(1:5),glcm_homogeneity(1:5),rata2,std_deviation,glcm_entropy,rata2_variance,glcm_kurtosis,glcm_skewness];

test_data=cell2mat(buat_train);

disp('GLCM Feature')
disp('Contrast(1) Correlation(2) Energy(3)  Homogeneity(4) Mean(5)  Standard_Deviation(6) Entropy(7) RMS(8) Variance(9) smoothness(10) Kurtosis(11) Skewness(12) IDM(13)')

input_Feature=test_data 

load('data_1.mat');
load('Gaborfeature.mat');
result = multisvm(data_feat,data_label,test_data);

if result == 1 && area <= 3000
    A1 = 'actinic keratosis';
    set(handles.edit2,'string',A1);
    helpdlg('ACTINIC KERATOSIS: Benign Cells are found');
    disp('actinic Keratosis');
elseif result == 1 && area > 3000
    A1 = 'actinic keratosis';
    set(handles.edit2,'string',A1);
    helpdlg('ACTINIC KERATOSIS: Malignant Cells are found ');
    disp('actinic Keratosis');
elseif result == 2 && area <= 3000
    A2 = 'Basel cell Carcinoma';
    set(handles.edit2,'string',A2);
    helpdlg('BASEL CELL CARCINOMA: Benign Cells are found');
    disp('Basel cell Carcinoma');
elseif result == 2 && area > 3000
    A2 = 'Basel cell carcinoma';
    set(handles.edit2,'string',A2);
    helpdlg('BASEL CELL CARCINOMA: Malignant Cells are found');
    disp('Basel cell carcinoma');
elseif result == 3 && area <= 3000
    A3 = 'cherry nevus';
    set(handles.edit2,'string',A3);
    helpdlg('CHERRY NEVUS: Benign Cells are found');
    disp('cherry nevus');
elseif result == 3 && area > 3500
    A3 = 'cherry nevus';
    set(handles.edit2,'string',A3);
    helpdlg('CHERRY NEVUS: Malignant Cells are found');
    disp('cherry nevus');
elseif result == 4 && area <= 3000
    A4 = 'dermatofibroma';
    set(handles.edit2,'string',A4);
    helpdlg('DERMATOFIBROMA: Benign Cells are found');
    disp('dermatofibroma');
elseif result == 4
    A4 = 'dermatofibroma';
    set(handles.edit2,'string',A4);
    helpdlg('DERMATOFIBROMA: Malignant Cells are found');
    disp('dermatofibroma');
elseif result == 5 && area <= 3000
    A5 = 'Melanocytic nevus';
    set(handles.edit2,'string',A5);
    helpdlg('MELANOCYTIC NEVUS: Benign Cells are found');
    disp('Melanocytic nevus');
elseif result == 5 && area > 3000
    A5 = 'Melanocytic nevus';
    set(handles.edit2,'string',A5);
    helpdlg('MELANOCYTIC NEVUS: Malignant Cells are found');
    disp('Melanocytic nevus');
elseif result == 6 && area <= 3000
    A5 = 'Melanoma';
    set(handles.edit2,'string',A5);
    helpdlg('MELANOMA: Benign cells are found');
    disp('Melanoma');
elseif result == 6 && area > 3000
    A5 = 'Melanoma';
    set(handles.edit2,'string',A5);
    helpdlg('MELANOMA: Malignant cells are found');
    disp('Melanoma');
end

function [result] = multisvm(TrainingSet,GroupTrain,TestSet)

u=unique(GroupTrain);
numClasses=length(u);
result = zeros(length(TestSet(:,1)),1);

for k=1:numClasses
    G1vAll=(GroupTrain==u(k));
    models(k) = svmtrain(TrainingSet,G1vAll);
end

for j=1:size(TestSet,1)
    for k=1:numClasses
     
        if(svmclassify(models(k),TestSet(j,:))) 
            break;
        end
    end
    result(j) = k;
    
end
function exCode1()
folder = 'Dataset'; 
dirImage = dir( folder ); 

numData = size(dirImage,1); 

M ={} ; 

for i=1:numData
    nama = dirImage(i).name;  
    if regexp(nama, '(D|F)-[0-9]{1,2}.jpg')
   
       B = cell(1,2); 
        if regexp(nama, 'D-[0-9]{1,2}.jpg')
      
            B{1,1} = double(imread([folder, '/', nama]));
            B{1,2} = 1; 
        elseif regexp(nama, 'F-[0-9]{1,2}.jpg')
         
            B{1,1} = double(imread([folder, '/', nama]));
            B{1,2} = -1; 
      end
        M = cat(1,M,B); 
    end
end

numDataTrain = size(M,1); 
class = zeros(numDataTrain,1);
arrayImage = zeros(numDataTrain, 300 * 300);

for i=1:numDataTrain
    im = M{i,1} ;
    im = rgb2gray(im); 
    im = imresize(im, [300 300]); 
    im = reshape(im', 1, 300*300); 
    arrayImage(i,:) = im; 
    class(i) = M{i,2}; 
end

SVMStruct = svmtrain(arrayImage, class);

imTest = double(imread(s)); 
imTest = rgb2gray(imTest); 
imTest = imresize(imTest, [300 300]); 
imTest = reshape(imTest',1, 300*300); 
result = svmclassify(SVMStruct, imTest);
if(result==1)
    msgbox('Desert');
else
    msgbox('Forest');
end
function exCode2()
    folder = 'Dataset'; 
dirImage = dir( folder ); 

numData = size(dirImage,1); 

M ={} ; 

for i=1:numData
    nama = dirImage(i).name;  
    if regexp(nama, '(M|R)-[0-9]{1,2}.jpg')
   
       B = cell(1,2); 
        if regexp(nama, 'M-[0-9]{1,2}.jpg')
      
            B{1,1} = double(imread([folder, '/', nama]));
            B{1,2} = 1; 
        elseif regexp(nama, 'R-[0-9]{1,2}.jpg')
         
            B{1,1} = double(imread([folder, '/', nama]));
            B{1,2} = -1; 
      end
        M = cat(1,M,B); 
    end
end

numDataTrain = size(M,1); 
class = zeros(numDataTrain,1);
arrayImage = zeros(numDataTrain, 300 * 300);

for i=1:numDataTrain
    im = M{i,1} ;
    im = rgb2gray(im); 
    im = imresize(im, [300 300]); 
    im = reshape(im', 1, 300*300); 
    arrayImage(i,:) = im; 
    class(i) = M{i,2}; 
end

SVMStruct = svmtrain(arrayImage, class);

imTest = double(imread(s)); 
imTest = rgb2gray(imTest); 
imTest = imresize(imTest, [300 300]); 
imTest = reshape(imTest',1, 300*300); 
result = svmclassify(SVMStruct, imTest);
if(result==1)
    msgbox('Mountain');
else
    msgbox('Residential');
end
function exCode3()
    folder = 'Dataset'; 
dirImage = dir( folder ); 

numData = size(dirImage,1); 

M ={} ; 

for i=1:numData
    nama = dirImage(i).name;  
    if regexp(nama, '(RI|D)-[0-9]{1,2}.jpg')
   
       B = cell(1,2); 
        if regexp(nama, 'RI-[0-9]{1,2}.jpg')
      
            B{1,1} = double(imread([folder, '/', nama]));
            B{1,2} = 1; 
        elseif regexp(nama, 'D-[0-9]{1,2}.jpg')
         
            B{1,1} = double(imread([folder, '/', nama]));
            B{1,2} = -1; 
      end
        M = cat(1,M,B); 
    end
end

numDataTrain = size(M,1); 
class = zeros(numDataTrain,1);
arrayImage = zeros(numDataTrain, 300 * 300);

for i=1:numDataTrain
    im = M{i,1} ;
    im = rgb2gray(im); 
    im = imresize(im, [300 300]); 
    im = reshape(im', 1, 300*300); 
    arrayImage(i,:) = im; 
    class(i) = M{i,2}; 
end

SVMStruct = svmtrain(arrayImage, class);

imTest = double(imread(s)); 
imTest = rgb2gray(imTest); 
imTest = imresize(imTest, [300 300]); 
imTest = reshape(imTest',1, 300*300); 
result = svmclassify(SVMStruct, imTest);
if(result==1)
    msgbox('River');
else
    msgbox('Desert');
end
function edit2_Callback(hObject, eventdata, handles)
function edit2_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function pushbutton15_Callback(hObject, eventdata, handles)
function pushbutton16_Callback(hObject, eventdata, handles)
str=get(handles.edit1,'String');
I1 = imread(str);
I4 = imadjust(I1,stretchlim(I1));
I5 = imresize(I4,[300,400]);
figure
imshow(I5);title(' Processed Image ');
set(handles.pushbutton1,'enable','off');    
set(handles.pushbutton16,'enable','off');
set(handles.pushbutton12,'enable','on');
function pushbutton17_Callback(hObject, eventdata, handles)
function edit3_Callback(hObject, eventdata, handles)
function edit3_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end