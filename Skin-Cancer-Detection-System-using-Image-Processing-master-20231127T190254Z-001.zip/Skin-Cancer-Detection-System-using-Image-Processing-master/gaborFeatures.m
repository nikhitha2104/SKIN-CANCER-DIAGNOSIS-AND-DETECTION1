function featureVector = gaborFeatures(img,gaborArray,d1,d2)

if (nargin ~= 4)        
    error('Please use the correct number of input arguments!')
end

if size(img,3) == 3     
    warning('The input RGB image is converted to grayscale!')
    img = rgb2gray(img);
end

img = double(img);

[u,v] = size(gaborArray);
gaborResult = cell(u,v);
for i = 1:u
    for j = 1:v
        gaborResult{i,j} = imfilter(img, gaborArray{i,j});
    end
end

featureVector = [];
for i = 1:u
    for j = 1:v
        
        gaborAbs = abs(gaborResult{i,j});
        gaborAbs = downsample(gaborAbs,d1);
        gaborAbs = downsample(gaborAbs.',d2);
        gaborAbs = gaborAbs(:);
        gaborAbs = (gaborAbs-mean(gaborAbs))/std(gaborAbs,1);
        featureVector =  [featureVector; gaborAbs];
        
    end
end